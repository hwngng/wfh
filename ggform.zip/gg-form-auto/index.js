const { Random } = require('random-js')
const { executablePath } = require('puppeteer')
const puppeteer = require('puppeteer-extra')
const StealthPlugin = require('puppeteer-extra-plugin-stealth')
const fs = require('fs')
const path = require('path')

const random = new Random()
puppeteer.use(StealthPlugin())
const form_url = 'https://forms.gle/TrQQKcC8joAqfk4aA'
const form_checkbox_ids = ['i27', 'i87', 'i110']
var alreadyresponsed = 0
var submitted = 0
var loginSuccess = 0
var loginFailed = 0
const failedLogPath = path.join(__dirname, 'failed.txt')

const vote = async (username, password) => {
	console.log('---------------------------------')
	console.log(`Username: ${username}. Password: ${password}`)
	const browser = await puppeteer.launch({
		headless: true,
		executablePath: executablePath()
	})
	const page = await browser.newPage()
	console.log('Logging into google...')
	await page.goto('https://accounts.google.com/')
	await page.waitForTimeout(random.integer(500, 1000))

	await page.waitForSelector('input[type="email"]')
	await page.focus('input[type="email"]')
	await page.waitForTimeout(random.integer(500, 1000))
	await page.keyboard.type(username, { delay: random.integer(20, 70) })

	await page.waitForTimeout(random.integer(200, 1000))
	await page.waitForSelector('#identifierNext')
	await page.click('#identifierNext')

	await page.waitForNavigation()

	await page.waitForSelector('input[type="password"]')
	await page.focus('input[type="password"]')
	await page.waitForTimeout(random.integer(1000, 2000))
	await page.keyboard.type(password, { delay: random.integer(20, 70) })

	await page.waitForSelector('#passwordNext')
	await page.waitForTimeout(random.integer(200, 1000))
	await page.click('#passwordNext')
	
	await page.waitForNavigation()
	let url = page.url()
	if (url.includes('speedbump')) {
		await page.waitForTimeout(random.integer(800, 1200))
		let confirmUnderstand = await page.waitForSelector('#confirm')
		await confirmUnderstand.click({ delay: 200 })
		await page.waitForNavigation()
		url = page.url()
	}
	let success = (url.includes('myaccount.google.com') || url.includes('gds.google.com')) ? true : false
	console.log('Submitted info. Result: ' + (success ? 'Success' : 'Failed'))
	if (!success) {
		loginSuccess++
	} else {
		loginFailed++
		fs.appendFileSync(failedLogPath, `${username} ${password}\n`)
		await browser.close()
		return
	}

	await page.waitForTimeout(random.integer(500, 1000))
	console.log('Going to google form...')
	await page.goto('https://forms.gle/TrQQKcC8joAqfk4aA')
	await page.waitForNavigation()
	let responded = page.url().includes('alreadyresponded')
	if (responded) {
		alreadyresponsed++
		await page.waitForTimeout(random.integer(200, 600))
		await browser.close()
		return
	}

	await page.waitForTimeout(random.integer(1500,2000))
	await page.keyboard.press('Enter')
	await page.waitForTimeout(random.integer(900,1600))
	let [clearFormSpan] = await page.$x('//div[@role="button"]/span[contains(., "Clear form")]')
	let [clearFormBtn] = await clearFormSpan.$x('..')
	await clearFormBtn.click({ delay: 200 })
	await page.waitForTimeout(random.integer(700,1000))
	let [clearFormSpan1] = await page.$x('(//div[@role="alertdialog"]//div[@role="button"]/span[contains(., "Clear form")])[2]')
	let [clearFormBtn1] = await clearFormSpan1.$x('..')
	await clearFormBtn1.click({ delay: 200 })
	await page.waitForTimeout(random.integer(1500,2000))
	for (let i = 0; i < form_checkbox_ids.length; ++i) {
		let checkbox = await page.waitForSelector('#' + form_checkbox_ids[i])
		await checkbox.click({ delay: 200 })
		await page.waitForTimeout(random.integer(700,1000))
	}
	let [submitSpan] = await page.$x('//div[@role="button"]/span[contains(., "Submit")]')
	let [submitButton] = await submitSpan.$x('..')
	await submitButton.click({ delay: 300 })
	submitted++
	await page.waitForTimeout(random.integer(1500,2000))
	await browser.close()
	// await page.waitForTimeout(300000)
}

const filePath = path.join(__dirname, 'accounts.txt')
fs.readFile(filePath, { encoding: 'utf-8' }, async function (err, data) {
	if (!err) {
		infos = data.split('\n')
		for (let i = 0; i < infos.length; ++i) {
			info = infos[i].trim().split(' ')
			if (info.length == 2) {
				await vote(info[0], info[1])
				console.log(`Read account: ${i+1}. Successfully login: ${loginSuccess}. Successfully submit: ${submitted}. Already responded: ${alreadyresponsed}`)
			}
		}
	} else {
		console.log(err)
	}
})
// vote('trieuthao738415@watbanchumsaengschool.com', 'Anhtai777')